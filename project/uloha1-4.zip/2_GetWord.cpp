#include "2_GetWord.h"

//2. uloha
int numberOfWords(const char *text) {
    if (text == nullptr or *text == '\0') return 0;
    //*(a + 0)
    int word_count = 1;
    if (isDelimiter(*text)==true) word_count = 0;

    for(size_t i = 0; *(text + i) != '\0'; i++){
        if (isDelimiter(*(text + i)) == true && isDelimiter(*(text + i+1)) == false
            && *(text + i+1) != '\0')
            word_count++;
    }
    return word_count;
}

const char *copyNthWord(const char *text, char *word, int orderNumber) {
    if(text == nullptr or word == nullptr) return EMPTY_WORD;
    const char *wordStart = findNthWord(text, orderNumber);

    if (*wordStart == '\0') return EMPTY_WORD;

    int len = 0;
     for (const char *my_pointer = wordStart; *my_pointer != '\0'; my_pointer++ ){
        if ( isDelimiter(*my_pointer)== true) {
            *(word + len) = '\0';
            return word;
        }
        *(word+len) = *my_pointer;
        len++;
    }
    *(word + len) = '\0';
    return word;
}
