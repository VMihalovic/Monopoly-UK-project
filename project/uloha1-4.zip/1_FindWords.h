#pragma once

#include <cstring> /* strcmp */

const char EMPTY_WORD[] { '\0' };
const double EMPTY_DOUBLE = 0.0;

//1. uloha
bool isDelimiter(char d);
const char *findNthOccurrence(const char *text, char character, int orderNumber);
const char *findNthWord(const char *text, int orderNumber);

const char DELIMITERS[] {' ', '.', ',', ';', '?', '!', ':', '(', ')', '[', ']'};
const int DUMMY_INT = -1;
const double DUMMY_DOUBLE_ARRAY[] { -1.1 };
const char DUMMY_CHAR_ARRAY[] {'\0' };
const bool DUMMY_BOOL = false;

