#pragma once

#include "4_SortWords.h"

//5. uloha
void sortWordsInSmallAndCh(char *listOfWords[], int count);
const char *sortAccordingToFunction(const char *text, char *output, void sortingFunction(char *arraysOfText[], int count));
int compareTwoWordsSpecial(const void *a, const void *b) ;
void toLowerAndChange(char *word);