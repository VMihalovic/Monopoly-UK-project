#pragma once

#include "1_FindWords.h"
//2. uloha
int numberOfWords(const char *text);
const char *copyNthWord(const char *text, char *word, int orderNumber);
