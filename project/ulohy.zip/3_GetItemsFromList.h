#pragma once

#include "2_GetWord.h"

const unsigned int MAX = 256;

//3.uloha
const double *findMaximum(const double data[], size_t count);
const char *selectWords(const char *text, char *listOfWords
                                , const int listOfOrders[], int numberOfOrders);
