#include "2_GetWord.h"

//2. uloha
int numberOfWords(const char *text) {
    if (text == nullptr or *text == '\0') return 0;

    int word_count = 1;

    if (isDelimiter(*text)==true)
        word_count = 0;

    while(*text != '\0'){
        if (isDelimiter(*text) == true && isDelimiter(*(text+1)) == false && *(text+1) != '\0')
            word_count++;
        text++;
    }
    return word_count;
}

const char *copyNthWord(const char *text, char *word, int orderNumber) {
    if(text == nullptr or word == nullptr) return EMPTY_WORD;

    const char *wordStart = findNthWord(text, orderNumber);

    if (*wordStart == '\0') {
        *word = '\0';
        return word;
    }

    int len = 0;
     while(*(wordStart+len) != '\0'){
        if ( isDelimiter(*(wordStart+len))== true) {
            *(word+ len) = '\0';
            return word;
        }
        *(word + len) = *(wordStart+len);
        len++;

    }
    *(word + len) = '\0';
    return word;
}
