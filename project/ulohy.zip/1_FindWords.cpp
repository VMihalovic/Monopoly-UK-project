#include "1_FindWords.h"

//1. uloha
bool isDelimiter(char d) {
    for ( char delimiter:DELIMITERS) {
        if (d == delimiter) return true;
    }
  return false;
}

const char *findNthOccurrence(const char *text, char character, int orderNumber) {
    if (text == nullptr or orderNumber < 1) return EMPTY_WORD;

    int order = 0;
    for(size_t i = 0; *text != '\0'; i++){
        if (*text == character)
            order++;
        if (order == orderNumber)
            return text;
        text++;
    }

    return EMPTY_WORD;
}

const char *findNthWord(const char *text, int orderNumber) {

    if (text == nullptr or orderNumber < 1) return EMPTY_WORD;

    if (isDelimiter(text[0])!=true && orderNumber == 1)
        return &text[0];
    int order = 1;

    if (isDelimiter(text[0])==true)
        order = 0;

    for(size_t i = 0; *text != '\0'; i++){
        if (isDelimiter(*text) == true && isDelimiter(*(text+1)) == false && *(text+1) != '\0')
            order++;
        if (order == orderNumber)
            return (text+1);
        text++;
    }

    return EMPTY_WORD;
}
